#include <iostream>
using namespace std;

#include "BST.h"

int main(){
    BST<int> list; 
    
    // list.insert(20);
    // list.insert(11);
    // list.insert(3);
    // list.insert(15);
    // list.insert(1);
    // list.insert(12);
    // list.insert(9);
    // list.insert(10);
    // list.insert(6);
    // list.insert(7);
    // list.insert(4);
    // list.insert(5);
    // list.insert(35); 
    // list.insert(23);
    // list.insert(60);
    // list.insert(22);
    // list.insert(21); 
    // list.insert(25);
    // list.insert(24); 
    // list.insert(27); 
    // list.insert(26); 
    // list.insert(29); 
    // list.insert(43);
    // list.insert(74);
    // list.insert(67);
    // list.insert(37);
    // list.insert(36); 
    // list.insert(41); 
    // list.insert(38);     
    
    // if(list.find(1) == true){
    //     cout<<"1 is in the list"<<endl;
    // }
    // else{
    //     cout<<"1 is not in the list "<<endl;
    // }
    // cout<<"tree"<<endl;
    // list.print(); 
    
    // cout<<"delete 1"<<endl;
    // list.delete_data(1); 
    // if(list.find(1) == true){
    //     cout<<"1 is in the list"<<endl;
    // }
    // else{
    //     cout<<"1 is not in the list "<<endl;
    // }
    // list.print(); 
    // cout<<"delete 9"<<endl;
    // list.delete_data(9);
    // // list.print(); 
    // // cout<<"delete 38"<<endl;
    // list.delete_data(38); 
    // // list.print(); 
    // // cout<<"delete 25"<<endl;
    // list.delete_data(25)
    // // list.print(); 
    // // cout<<"delete root"<<endl;
    // list.delete_data(20); 
    // list.print(); 
    // list.insert(10); 
    // list.insert(5); 
    // list.delete_data(10); 
    // list.print();    

    list.insert(12);
    list.insert(7);
    list.insert(21);
    list.insert(4);
    list.insert(9);
    list.insert(2);
    list.insert(8);

    cout<<"Preorder view"<<endl;
    list.visit(1); 
    cout<<endl;

    cout<<"Inorder view"<<endl;
    list.visit(2); 
    cout<<endl;

    cout<<"postorder view"<<endl;
    list.visit(3); 
    cout<<endl; 

    cout<<"by level view"<<endl; 
    list.visit(4); 
    cout<<endl; 

    cout<<"size: "<<list.height()<<endl;; 
    
    cout<<"ancestors of 8"<<endl; 
    list.ancestors(8); 
    cout<<endl; 

    cout<<"find level of 8 "<<endl; 
    cout<<list.what_level(8)<<endl; 

    return 0;
}
